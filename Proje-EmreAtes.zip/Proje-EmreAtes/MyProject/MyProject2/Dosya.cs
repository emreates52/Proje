﻿namespace MyProject2
{
    public class Dosya : IArayuz<Kitap>
    {
        public Kitap Ara(int id)
        {
            StreamReader reader = new StreamReader("kitap.data");

            Kitap kitap = new Kitap();
            string kitapid = id.ToString();

            while (!reader.EndOfStream)
            {

                string strPersonel = reader.ReadLine();
                var data = strPersonel.Split(";");


                if (strPersonel.StartsWith(kitapid))
                {

                    kitap.KitapID = Convert.ToInt32(data[0]);
                    kitap.KitapAdi = data[1];
                    kitap.Yazar = data[2];
                    kitap.Fiyat = Convert.ToDouble(data[3]);

                }
                else continue;
            }

            reader.Close();
            return kitap;
        }

        public void Ekle(Kitap kitap)
        {
            StreamWriter writer = new StreamWriter("kitap.data", true);

            string strKitap = $"{kitap.KitapID}; {kitap.KitapAdi}; {kitap.Yazar}; {kitap.Fiyat}";

            writer.WriteLine(strKitap);
            writer.Close();
        }

        public List<Kitap> Listele()
        {
            StreamReader reader = new StreamReader("kitap.data");
            List<Kitap> kitaplar = new List<Kitap>();

            while (!reader.EndOfStream)
            {
                string strPersonel = reader.ReadLine();
                var data = strPersonel.Split(";");

                Kitap kitap = new Kitap();
                kitap.KitapID = Convert.ToInt32(data[0]);
                kitap.KitapAdi = data[1];
                kitap.Yazar = data[2];
                kitap.Fiyat = Convert.ToDouble(data[3]);

                kitaplar.Add(kitap);
            }
            reader.Close();
            return kitaplar;
        }

        public List<Kitap> KelimeAra(string ad)
        {
            StreamReader reader = new StreamReader("kitap.data");
            List<Kitap> kitaplar = new List<Kitap>();

            while (!reader.EndOfStream)
            {
                string strPersonel = reader.ReadLine();

                //convert both to lowercase for Case-Insensitive Matching
                string strTemp = strPersonel.ToLower();
                ad = ad.ToLower();

                if (strTemp.Contains(ad))
                {
                    var data = strPersonel.Split(";");

                    Kitap kitap = new Kitap();
                    kitap.KitapID = Convert.ToInt32(data[0]);
                    kitap.KitapAdi = data[1];
                    kitap.Yazar = data[2];
                    kitap.Fiyat = Convert.ToDouble(data[3]);

                    kitaplar.Add(kitap);
                }
                else continue;
            }

            reader.Close();

            return kitaplar;
        }
        public int lastIndexofDosya()
        {
            int lastindex;
            if (new FileInfo("kitap.data").Length == 0)
            {
                lastindex = 0;
            }
            else
            {
                var lastLine = File.ReadLines("kitap.data").Last();
                var data = lastLine.Split(";");
                lastindex = Convert.ToInt32(data[0]);
            }
            return lastindex + 1;
        }
    }
}
