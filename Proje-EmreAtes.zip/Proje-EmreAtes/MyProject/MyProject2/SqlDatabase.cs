﻿using System.Data.SqlClient;

namespace MyProject2
{
    public class SqlDatabase : IArayuz<Kitap>
    {
        string strConn = "Data source=.;initial catalog=KitapDB;integrated security=true";
        public Kitap Ara(int id)
        {
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();

            SqlCommand cmd = new SqlCommand("SELECT * FROM Kitaplar WHERE KitapID=@ID", conn);
            cmd.Parameters.AddWithValue("@ID", id);

            SqlDataReader dr = cmd.ExecuteReader();
            Kitap kitap = new Kitap();      //{ KitapID = -1 };

            dr.Read();
            if (dr.HasRows)
            {
                kitap.KitapID = Convert.ToInt32(dr[0]);
                kitap.KitapAdi = dr.GetString(1);
                kitap.Yazar = dr.GetString(2);
                kitap.Fiyat = Convert.ToDouble(dr[3]);
            }
            conn.Close();
            return kitap;
        }

        public void Ekle(Kitap kitap)
        {
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();

            SqlCommand cmd = new SqlCommand("INSERT INTO Kitaplar VALUES(@kitapadi,@yazar,@fiyat)", conn);

            cmd.Parameters.AddWithValue("@kitapadi", kitap.KitapAdi);
            cmd.Parameters.AddWithValue("@yazar", kitap.Yazar);
            cmd.Parameters.AddWithValue("@fiyat", kitap.Fiyat);
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public List<Kitap> Listele()
        {
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Kitaplar", conn);

            SqlDataReader dr = cmd.ExecuteReader();
            List<Kitap> kitaplar = new List<Kitap>();
            while (dr.Read())
            {
                Kitap kitap = new Kitap();
                kitap.KitapID = Convert.ToInt32(dr[0]);
                kitap.KitapAdi = dr.GetString(1);
                kitap.Yazar = dr.GetString(2);
                kitap.Fiyat = Convert.ToDouble(dr[3]);

                kitaplar.Add(kitap);
            }
            conn.Close();
            return kitaplar;

        }

        public List<Kitap> KelimeAra(string ad)
        {
            List<Kitap> kitaplar = new List<Kitap>();
            SqlConnection conn = new SqlConnection(strConn);
            conn.Open();

            SqlCommand cmd = new SqlCommand("SELECT * FROM Kitaplar WHERE Yazar LIKE @AD or KitapAdi LIKE @AD", conn);

            cmd.Parameters.AddWithValue("@AD", "%" + ad + "%");     //içinde geçiyor mu diye bu

            SqlDataReader dr = cmd.ExecuteReader();
            //Personel personel = new Personel() { PersonelID = -1 };

            while (dr.Read())
            {
                if (dr.HasRows)
                {
                    Kitap kitap = new Kitap();
                    kitap.KitapID = Convert.ToInt32(dr[0]);
                    kitap.KitapAdi = dr.GetString(1);
                    kitap.Yazar = dr.GetString(2);
                    kitap.Fiyat = Convert.ToDouble(dr[3]);

                    kitaplar.Add(kitap);
                }
            }
            conn.Close();
            return kitaplar;
        }
    }
}
