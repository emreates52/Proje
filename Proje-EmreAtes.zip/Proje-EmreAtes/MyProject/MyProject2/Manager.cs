﻿namespace MyProject2
{
    public class Manager : IArayuz<Kitap>
    {
        private IArayuz<Kitap> _db;
        List<Kitap> list = new List<Kitap>();

        //ctor injection
        public Manager(IArayuz<Kitap> db)
        {
            _db = db;
        }

        public Kitap Ara(int id)
        {
            Kitap kitap = _db.Ara(id);
            if (kitap.KitapID > 0)
                Console.WriteLine(id + " numaralı aranan kitap bulundu: \n" + kitap);
            else
                Console.WriteLine(id + " numaralı aradığınız kitap bulunamadi..."); ;
            return kitap;
        }

        public void Ekle(Kitap kitap)
        {
            _db.Ekle(kitap);
            Console.WriteLine("Kayıt eklendi.");
        }

        public List<Kitap> Listele()
        {
            List<Kitap> books = new List<Kitap>();
            Console.WriteLine("Kayıtlar Listeleniyor...");
            if (_db.Listele().Any())
            {
                foreach (Kitap k in _db.Listele())
                    Console.WriteLine(k);
            }
            else
            {
                Console.WriteLine("There is no record.");
            }
            return books;

        }

        public List<Kitap> KelimeAra(string ad)
        {
            List<Kitap> books = new List<Kitap>();

            if (_db.KelimeAra(ad).Any())
            {
                Console.WriteLine(ad + " kelimesini içeren kayıt/kayıtlar Listeleniyor:");
                foreach (Kitap book in _db.KelimeAra(ad))
                    Console.WriteLine(book);
            }
            else
                Console.WriteLine(ad + " kelimesini içeren kayıt bulunamadı.");
            return books;
        }
    }
}
