﻿using MyProject;

DatabaseKontrol dbKontrol = new DatabaseKontrol();
DosyaKontrol dsyKontrol = new DosyaKontrol();

Console.WriteLine("Initially check Database and File exist or not \n...");
string databaseAdı = "KitapDB";
string dosyaAdı = "kitap.data";

//Veribanı VAR mı, YOK ise OLUŞTUR kontrolleri
if (dbKontrol.CheckDatabaseExists(databaseAdı))
{
    Console.WriteLine(databaseAdı + "  exists!");
}
else
{
    dbKontrol.CreateDatabase(databaseAdı);
    dbKontrol.CreateTable(databaseAdı);
}

//Dosya VAR mı, YOK ise OLUŞTUR kontrolu
dsyKontrol.CheckFileExist(dosyaAdı);
//-------------------------------------------------------------------------

SqlDatabase sqlDB = new SqlDatabase();
Dosya dsy = new Dosya();
Console.WriteLine();

Manager dbm = new Manager(sqlDB);         //it could take either Veritabani or Dosya
//dbm.Ekle(new Kitap { KitapAdi = "Faust", Yazar = "Goethe", Fiyat = 35.50 });
dbm.Listele();
dbm.Ara(6);

//Console.WriteLine(new string('-', 50));

//Manager dbm2 = new Manager(dsy);
//dbm2.Ekle(new Kitap { KitapID = 1, KitapAdi = "Faust", Yazar = "Goethe", Fiyat = 35.50 });
//dbm2.Listele();
//dbm2.Ara(4);

///////////////////dosyaya toplu ekleme için,  Fiyat default value=54.80 at ctor
/*
List<Kitap> books = new List<Kitap> {
 new Kitap { KitapID=1, KitapAdi="Denemeler",Yazar="Montaigne", Fiyat=14.75 },
 new Kitap { KitapID=2, KitapAdi="Suç ve Ceza",Yazar="Dostoyevski", Fiyat=79.99 },
 new Kitap { KitapID=3, KitapAdi="Da Vinci'nin Sifresi",Yazar="Dan Brown", Fiyat=35.5 },
 new Kitap { KitapID=4, KitapAdi="Sefiller",Yazar="Victor Hugo", Fiyat=24.25 },
 new Kitap { KitapID=5, KitapAdi="Kumarbaz",Yazar="Dostoyevski" },
 new Kitap { KitapID=6, KitapAdi="Oliver Twist",Yazar="Charles Dickens", Fiyat=20 },
 new Kitap { KitapID=7, KitapAdi="Hobbit",Yazar="J.R.R Tolkien", Fiyat=48.6 },
 new Kitap { KitapID=8, KitapAdi="LOTR",Yazar="J.R.R Tolkien", Fiyat=62.87 },
 new Kitap { KitapID=9, KitapAdi="Cehennem",Yazar="Dan Brown", Fiyat= 54.99 },
 new Kitap { KitapID=10, KitapAdi="Anna Karenina",Yazar="Tolstoy" },
 new Kitap { KitapID=11, KitapAdi="Faust",Yazar="Goethe", Fiyat=50.50 },
 new Kitap { KitapID=12, KitapAdi="Harry Potter",Yazar="J.K Rowling" }
};

for (int i = 0; i < books.LongCount(); i++)
{
    dsy.Ekle(new Kitap { KitapID=books[i].KitapID, KitapAdi=books[i].KitapAdi, Yazar = books[i].Yazar, Fiyat= books[i].Fiyat });
    //sqlDB.Ekle(new Kitap { KitapID=books[i].KitapID, KitapAdi=books[i].KitapAdi, Yazar = books[i].Yazar, Fiyat= books[i].Fiyat });
    
}
*/
