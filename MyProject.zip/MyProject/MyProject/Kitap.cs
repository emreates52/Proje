﻿namespace MyProject
{
    public class Kitap
    {
        public int KitapID { get; set; }
        public string KitapAdi { get; set; }
        public string Yazar { get; set; }
        public double Fiyat { get; set; } = 54.80;      //default value

        public override string ToString()
        {
            return $"{KitapID,-5} {KitapAdi,-25} {Yazar,-25} {Fiyat,-5}";
        }
    }
}
