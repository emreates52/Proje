﻿namespace MyProject
{
    public class DosyaKontrol
    {
        public void CheckFileExist(string txtFile)
        {

            string temp = AppDomain.CurrentDomain.BaseDirectory;
            string sPath = Path.Combine(temp, txtFile);

            bool fileExist = File.Exists(sPath);
            if (fileExist)
            {
                Console.WriteLine(txtFile + " exists!");
            }
            else
            {
                using (File.Create(sPath));
                Console.WriteLine(txtFile + " oluşturuldu.");
            }
        }
    }
}
