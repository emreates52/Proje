﻿using System.Data.SqlClient;

namespace MyProject2
{
    public class DatabaseKontrol
    {
        public bool CheckDatabaseExists(string dataBase)
        {
            string conStr = "Data source=.;initial catalog=master; integrated security=true";

            string cmdText = "SELECT * FROM master.dbo.sysdatabases WHERE name ='" + dataBase + "'";
            bool isExist = false;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(cmdText, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        isExist = reader.HasRows;
                    }
                }
                con.Close();
            }
            return isExist;
        }

        public void CreateDatabase(string dataBase)
        {
            string conStr = "Data source=.;initial catalog=master; integrated security=true";

            SqlConnection con = new SqlConnection(conStr);
            string str = "CREATE DATABASE " + dataBase;

            SqlCommand cmd = new SqlCommand(str, con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Console.WriteLine(dataBase + " is created Successfully!");
        }
        public void CreateTable(string dataBase)
        {
            string conStr = "Data source=.;initial catalog=" + dataBase + "; integrated security=true";
            SqlConnection con = new SqlConnection(conStr);
            string str = "CREATE TABLE [" + dataBase + "].dbo.Kitaplar(KitapID int IDENTITY PRIMARY KEY,KitapAdi varchar(30),Yazar varchar(30),Fiyat float)";

            SqlCommand cmd = new SqlCommand(str, con);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            Console.WriteLine("Kitaplar TABLE is created Successfully!");
        }

    }
}
