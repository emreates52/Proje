﻿namespace MyProject2
{
    public interface IArayuz<T> where T : class
    {
        T Ara(int id);
        List<T> Listele();
        void Ekle(T kitap);
        List<T> YazarAra(string ad);
    }
}
