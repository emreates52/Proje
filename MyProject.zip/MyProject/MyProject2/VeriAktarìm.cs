﻿using System.Data.SqlClient;

// Veritabanındaki veriyi Dosyaya yazan ve Dosyadaki verileri Veritabanına yazan 2 metod içerir.
namespace MyProject2
{
    public class VeriAktarım
    {
        public void databaseKayitlariDosyayaAktar()
        {
            string strConn = "Data source=.;initial catalog=KitapDB;integrated security=true";
            SqlConnection conn = new SqlConnection(strConn);

            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Kitaplar", conn);

            SqlDataReader dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                Kitap kitap = new Kitap();
                Dosya dosya = new Dosya();
                kitap.KitapID = dosya.lastIndexofDosya();   //en son ID'i 1 artıtarak ekler.

                kitap.KitapAdi = dr.GetString(1);
                kitap.Yazar = dr.GetString(2);
                kitap.Fiyat = Convert.ToDouble(dr[3]);

                dosya.Ekle(kitap);
            }
            conn.Close();
        }

        public void DosyadanOkuDatabaseYaz()
        {
            StreamReader reader = new StreamReader("kitap.data");

            while (!reader.EndOfStream)
            {
                string strPersonel = reader.ReadLine();
                var data = strPersonel.Split(";");

                Kitap kitap = new Kitap();
                //kitap.KitapID = Convert.ToInt32(data[0]);
                kitap.KitapAdi = data[1];
                kitap.Yazar = data[2];
                kitap.Fiyat = Convert.ToDouble(data[3]);

                SqlDatabase vt = new SqlDatabase();
                vt.Ekle(kitap);

            }

            reader.Close();
        }

    }
}
