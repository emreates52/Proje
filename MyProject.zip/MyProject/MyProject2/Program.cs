﻿using MyProject2;


DatabaseKontrol dbKontrol = new DatabaseKontrol();
DosyaKontrol dsyKontrol = new DosyaKontrol();
string databaseAdı = "KitapDB";
string dosyaAdı = "kitap.data";

Console.WriteLine("Initially check Database and File exist or not \n...");

//Veribanı VAR mı, YOK ise OLUŞTUR kontrolleri
if (dbKontrol.CheckDatabaseExists(databaseAdı))
{
    Console.WriteLine(databaseAdı + "  exists!");
}
else
{
    dbKontrol.CreateDatabase(databaseAdı);
    dbKontrol.CreateTable(databaseAdı);
}
//Dosya VAR mı, YOK ise OLUŞTUR kontrolu
dsyKontrol.CheckFileExist(dosyaAdı);
//-------------------------------------------------------------------------


//Definitions
VeriAktarım akt = new VeriAktarım();
SqlDatabase vtb = new SqlDatabase();
Dosya dsy = new Dosya();
Manager dbm = new Manager(vtb);
Manager dbm2 = new Manager(dsy);
Kitap kitap = new Kitap();

int x = 10;
Console.WriteLine("\nTEST MENU");

//Menu loop
while ( x!= 0)
{
    Console.WriteLine("-----------------------------------------------------");
    Console.WriteLine("Press 1 for Listing SQL data");
    Console.WriteLine("Press 2 for Adding data to SQL");
    Console.WriteLine("Press 3 for Search data in SQL (accoring to KitapID)");
    Console.WriteLine("Press 4 for Search string in SQL (Case-Insensitive)");
    Console.WriteLine("Press 5 for Listing data from File");
    Console.WriteLine("Press 6 for Adding data to File");
    Console.WriteLine("Press 7 for Search data in File (accoring to KitapID)");
    Console.WriteLine("Press 8 for Search string in File (Case-Insensitive)");
    Console.WriteLine("Press 9 for write the data from SQL to File");
    Console.WriteLine("Press 0 for Exit");

    int menu = Convert.ToInt32(Console.ReadLine());

    switch (menu)
    {
        case 1:     //sql'de listeleme   
            dbm.Listele();
            break;

        case 2:             //sql'e veri ekler. id hariç değerleri kullanıcıdan alır.
            Console.Write("Kitap Adı: ");
            string kitapAdi = Console.ReadLine();
            Console.Write("Yazar: ");
            string yazar = Console.ReadLine();
            Console.Write("Fiyat: ");
            double fiyat = Convert.ToDouble(Console.ReadLine());

            kitap.KitapAdi = kitapAdi;
            kitap.Yazar = yazar;
            kitap.Fiyat = fiyat;
            dbm.Ekle(kitap);

            break;

        case 3:             //PersonelID'ya göre arama yapıp listeler
            Console.Write("Veritabanında aramak istediğiniz KitapID giriniz:");
            int vid = Convert.ToInt32(Console.ReadLine());
            kitap= dbm.Ara(vid);
            break;

        case 4:             //Ad'a göre arayıp kayıt ve kayıtları listeler
            Console.WriteLine("Kitap ve ya Yazar adı arayabilirsiniz.\n" +
                 "ismin tamamı yerine bir kısmını da girebilirsiniz."); 
            string yazarAdı = Console.ReadLine();
            dbm.YazarAra(yazarAdı);
            break;

        case 5:             //dosyadaki verileri listeler
            foreach (Kitap k in dbm2.Listele())
                Console.WriteLine(k);
            break;

        case 6:
            Console.Write("Kitap Adı: ");
            string kitapAdi2 = Console.ReadLine();
            Console.Write("Yazar: ");
            string yazar2 = Console.ReadLine();
            Console.Write("Fiyat: ");
            double fiyat2 = Convert.ToDouble(Console.ReadLine());

            kitap.KitapID = dsy.lastIndexofDosya();
            kitap.KitapAdi = kitapAdi2;
            kitap.Yazar = yazar2;
            kitap.Fiyat = fiyat2;
            dbm2.Ekle(kitap);
            break;

        case 7:
            Console.Write("Dosyada aramak istediğiniz KitapID giriniz:");
            int did = Convert.ToInt32(Console.ReadLine());
            kitap = dbm2.Ara(did);
            break;

        case 8:
            Console.WriteLine("Kitap ve ya Yazar adı arayabilirsiniz.\n" +
                "ismin tamamı yerine bir kısmını da girebilirsiniz.");
            string yazarAdi2 = Console.ReadLine();
            dbm2.YazarAra(yazarAdi2);
            break;
        
        case 9:
            akt.databaseKayitlariDosyayaAktar();
            Console.WriteLine("Veritabanındaki kayıtlar dosyaya yazıldı.");
            //akt.DosyadanOkuDatabaseYaz();
            //Console.WriteLine("Dosyadaki kayıtlar veritabanına yazıldı.");
            break;
   
        case 0:
            x = 0;
            break;
    }
}

/*
Manager dbm = new Manager(vtb);         //it could take either Veritabani or Dosya

dbm.Listele();
dbm.Ara(6);
dbm.YazarAra("Dosto");      
//dbm.Ekle(new Kitap { KitapID = 25, KitapAdi = "Kara Kitap", Yazar = "Orhan Pamuk", Fiyat = 44.50 });
*/

///////////////////dosyaya toplu ekleme için,  Fiyat default value=54.80 at ctor
/*
List<Kitap> books = new List<Kitap> {
 new Kitap { KitapID=1, KitapAdi="Denemeler",Yazar="Montaigne", Fiyat=14.75 },
 new Kitap { KitapID=2, KitapAdi="Suç ve Ceza",Yazar="Dostoyevski", Fiyat=79.99 },
 new Kitap { KitapID=3, KitapAdi="Da Vinci'nin Sifresi",Yazar="Dan Brown", Fiyat=35.5 },
 new Kitap { KitapID=4, KitapAdi="Sefiller",Yazar="Victor Hugo", Fiyat=24.25 },
 new Kitap { KitapID=5, KitapAdi="Kumarbaz",Yazar="Dostoyevski" },
 new Kitap { KitapID=6, KitapAdi="Oliver Twist",Yazar="Charles Dickens", Fiyat=20 },
 new Kitap { KitapID=7, KitapAdi="Hobbit",Yazar="J.R.R Tolkien", Fiyat=48.6 },
 new Kitap { KitapID=8, KitapAdi="LOTR",Yazar="J.R.R Tolkien", Fiyat=62.87 },
 new Kitap { KitapID=9, KitapAdi="Cehennem",Yazar="Dan Brown", Fiyat= 54.99 },
 new Kitap { KitapID=10, KitapAdi="Anna Karenina",Yazar="Tolstoy" },
 new Kitap { KitapID=11, KitapAdi="Faust",Yazar="Goethe", Fiyat=50.50 },
 new Kitap { KitapID=12, KitapAdi="Harry Potter",Yazar="J.K Rowling" }
};

for (int i = 0; i < books.LongCount(); i++)
{
    dsy.Ekle(new Kitap { KitapID = books[i].KitapID, KitapAdi = books[i].KitapAdi, Yazar = books[i].Yazar, Fiyat = books[i].Fiyat });
    //vtb.Ekle(new Kitap { KitapID=books[i].KitapID, KitapAdi=books[i].KitapAdi, Yazar = books[i].Yazar, Fiyat= books[i].Fiyat });
}
*/